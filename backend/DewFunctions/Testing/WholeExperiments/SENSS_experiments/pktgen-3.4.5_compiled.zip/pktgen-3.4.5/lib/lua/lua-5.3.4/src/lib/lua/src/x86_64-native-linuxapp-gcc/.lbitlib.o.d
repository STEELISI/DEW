dep_lbitlib.o = /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/lbitlib.c \
 /usr/include/stdc-predef.h \
 /opt/netronome/srcpkg/dpdk-ns/x86_64-native-linuxapp-gcc/include/rte_config.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/lprefix.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/lua.h \
 /usr/lib/gcc/x86_64-linux-gnu/4.8/include/stdarg.h \
 /usr/lib/gcc/x86_64-linux-gnu/4.8/include/stddef.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/luaconf.h \
 /usr/lib/gcc/x86_64-linux-gnu/4.8/include-fixed/limits.h \
 /usr/lib/gcc/x86_64-linux-gnu/4.8/include-fixed/syslimits.h \
 /usr/include/limits.h /usr/include/features.h \
 /usr/include/x86_64-linux-gnu/sys/cdefs.h \
 /usr/include/x86_64-linux-gnu/bits/wordsize.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs-64.h \
 /usr/include/x86_64-linux-gnu/bits/posix1_lim.h \
 /usr/include/x86_64-linux-gnu/bits/local_lim.h \
 /usr/include/linux/limits.h \
 /usr/include/x86_64-linux-gnu/bits/posix2_lim.h \
 /usr/include/x86_64-linux-gnu/bits/xopen_lim.h \
 /usr/include/x86_64-linux-gnu/bits/stdio_lim.h /usr/include/stdio.h \
 /usr/include/x86_64-linux-gnu/bits/types.h \
 /usr/include/x86_64-linux-gnu/bits/typesizes.h /usr/include/libio.h \
 /usr/include/_G_config.h /usr/include/wchar.h \
 /usr/include/x86_64-linux-gnu/bits/sys_errlist.h \
 /usr/include/x86_64-linux-gnu/bits/stdio.h \
 /usr/include/x86_64-linux-gnu/bits/stdio2.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/lauxlib.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/lualib.h
