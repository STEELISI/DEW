dep_lgc.o = /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/lgc.c \
 /usr/include/stdc-predef.h \
 /opt/netronome/srcpkg/dpdk-ns/x86_64-native-linuxapp-gcc/include/rte_config.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/lprefix.h /usr/include/string.h \
 /usr/include/features.h /usr/include/x86_64-linux-gnu/sys/cdefs.h \
 /usr/include/x86_64-linux-gnu/bits/wordsize.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs-64.h \
 /usr/lib/gcc/x86_64-linux-gnu/4.8/include/stddef.h \
 /usr/include/x86_64-linux-gnu/bits/string.h \
 /usr/include/x86_64-linux-gnu/bits/string2.h /usr/include/endian.h \
 /usr/include/x86_64-linux-gnu/bits/endian.h \
 /usr/include/x86_64-linux-gnu/bits/types.h \
 /usr/include/x86_64-linux-gnu/bits/typesizes.h \
 /usr/include/x86_64-linux-gnu/bits/string3.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/lua.h \
 /usr/lib/gcc/x86_64-linux-gnu/4.8/include/stdarg.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/luaconf.h \
 /usr/lib/gcc/x86_64-linux-gnu/4.8/include-fixed/limits.h \
 /usr/lib/gcc/x86_64-linux-gnu/4.8/include-fixed/syslimits.h \
 /usr/include/limits.h /usr/include/x86_64-linux-gnu/bits/posix1_lim.h \
 /usr/include/x86_64-linux-gnu/bits/local_lim.h \
 /usr/include/linux/limits.h \
 /usr/include/x86_64-linux-gnu/bits/posix2_lim.h \
 /usr/include/x86_64-linux-gnu/bits/xopen_lim.h \
 /usr/include/x86_64-linux-gnu/bits/stdio_lim.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/ldebug.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/lstate.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/lobject.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/llimits.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/ltm.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/lzio.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/lmem.h /usr/include/signal.h \
 /usr/include/x86_64-linux-gnu/bits/sigset.h \
 /usr/include/x86_64-linux-gnu/bits/signum.h /usr/include/time.h \
 /usr/include/x86_64-linux-gnu/bits/siginfo.h \
 /usr/include/x86_64-linux-gnu/bits/sigaction.h \
 /usr/include/x86_64-linux-gnu/bits/sigstack.h \
 /usr/include/x86_64-linux-gnu/sys/ucontext.h \
 /usr/include/x86_64-linux-gnu/bits/sigcontext.h \
 /usr/include/x86_64-linux-gnu/bits/pthreadtypes.h \
 /usr/include/x86_64-linux-gnu/bits/sigthread.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/ldo.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/lfunc.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/lgc.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/lstring.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/ltable.h
