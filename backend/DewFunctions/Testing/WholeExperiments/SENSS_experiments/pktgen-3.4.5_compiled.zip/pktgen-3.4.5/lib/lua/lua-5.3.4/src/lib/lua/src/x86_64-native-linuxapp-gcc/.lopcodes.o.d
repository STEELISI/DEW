dep_lopcodes.o = /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/lopcodes.c \
 /usr/include/stdc-predef.h \
 /opt/netronome/srcpkg/dpdk-ns/x86_64-native-linuxapp-gcc/include/rte_config.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/lprefix.h \
 /usr/lib/gcc/x86_64-linux-gnu/4.8/include/stddef.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/lopcodes.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/llimits.h \
 /usr/lib/gcc/x86_64-linux-gnu/4.8/include-fixed/limits.h \
 /usr/lib/gcc/x86_64-linux-gnu/4.8/include-fixed/syslimits.h \
 /usr/include/limits.h /usr/include/features.h \
 /usr/include/x86_64-linux-gnu/sys/cdefs.h \
 /usr/include/x86_64-linux-gnu/bits/wordsize.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs-64.h \
 /usr/include/x86_64-linux-gnu/bits/posix1_lim.h \
 /usr/include/x86_64-linux-gnu/bits/local_lim.h \
 /usr/include/linux/limits.h \
 /usr/include/x86_64-linux-gnu/bits/posix2_lim.h \
 /usr/include/x86_64-linux-gnu/bits/xopen_lim.h \
 /usr/include/x86_64-linux-gnu/bits/stdio_lim.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/lua.h \
 /usr/lib/gcc/x86_64-linux-gnu/4.8/include/stdarg.h \
 /opt/pktgen-3.4.5/lib/lua/lua-5.3.4/src/luaconf.h
